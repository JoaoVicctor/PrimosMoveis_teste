# Primos Moveis Planejados

 Neste repositório, encontra-se todo o processo que foi utilizado na Criação do Sistema da Primos Moveis. Na aba Projects, encontramos como foi dividido cada processo e como foi tratado. 
 
 Em Branch: Encontramos todas as versões do Sistema. no Ramo Master, encontra a versão final e utilizada. 
 
 OBS: Para Execução do Projeto é necessário ter as seguintes PIPS INSTALADAS:
- pip install flask
- pip install flask_restful
- pip install Flask-SQLAlchemy
- pip install jsons
- pip install requests
- pip install pyodbc
- pip install Jinja2
- pip install Flask-EXT
- pip install mypy_entensions
- pip install typing extensions
- pip install wrap_connection
- pip install flask_login

Versão mais instável do projeto. 


Após a instalação, execute main.py
Criação dos models ClienteModel, TelefoneModel, EndereçosModel, CargoModel, FuncionarioModels, TiposModels, VendasModels e AcompanhamentoModels.
 
 Link do Site: --- AINDA SEM LINK --- 
 Link aplicativo Mobile --- http://jeffersonximenes.pythonanywhere.com/cliente --- 
 
- Equipe: Anna Kelly, Gabriel Bezerra, Hellen Mendes,Jefferson Ximenes e João Victor Nunes. 
